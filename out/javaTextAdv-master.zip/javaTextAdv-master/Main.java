import game.Spiel;

public class Main {
    public static void main(String[] args) {
        
        System.out.println("Willkommen zum Java-Adventure. Viel Spaß!");
        Spiel s = new Spiel(); 
        s.spielen();
        System.out.println("Bis zum nächsten mal, Bye Bye!");
        // selbsterklärende Startdatei
    }
}
