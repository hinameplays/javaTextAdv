package game.lib_custom.Render;

import java.awt.image.BufferedImage;

public class Frame {
    BufferedImage i;

    public Frame(int height, int width) {
        i = new BufferedImage(height, width, 10);
    }

    public Frame[][] split() {
        return null;
    }

    public float compare() {
        return 0;
    }
}
