# javaTextAdv

A simple Adventure game written in java using terminal out, see The Colossal Cave Adventure for comparable reference.

## ***important setup information (actually only applies to entry node for now)***

### **Starting the program via game/main.java is meta**

**Aktuell ist bereits ein Grundgerüst des Spiels implementiert. Die Anforderungsanalyse wurde auch nachgeholt. Nun werden mit der Zeit die beschriebenen Features implementiert. Aktuell ist nur Main.java (und Referenzen) relevant.**

Json-Library modified from <https://github.com/stleary/JSON-java>

## **Programm starten:**

Mainmethode in Main.java ausführen, z.B. über  
'find -name *.java > sources.txt && javac sources.txt'  
'java Main.class'

oder in einer IDE

### **Hierbei wurde jedoch das JDK 14.0.1 genutzt (target-Option beim kompilieren setzen!)**
